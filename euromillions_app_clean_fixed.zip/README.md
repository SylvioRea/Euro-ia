
# EuroMillions IA - Streamlit Web App (Version fonctionnelle)

- Menu de navigation latéral activé
- 4 pages connectées
- Icônes PWA + Manifest
- Prête à être hébergée sur Streamlit Cloud

1. Uploadez le contenu sur un repo GitHub
2. Allez sur https://streamlit.io/cloud
3. Connectez votre repo, choisissez Home.py
4. Cliquez sur "Deploy"

Utilisable sur ordi et installable comme App iPhone via Safari.
